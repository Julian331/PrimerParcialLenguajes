import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;

public class Main {

    static double factorial(int n){
        double f = 1;
        for(int i=1;i<=n;i++){
            f *= i;
        }
        return f;
    }

    static double maclaurin(double x, int n){

        double suma = 0;

        for(int i=0;i<n;i++){
            suma += Math.pow(x,i)/factorial(i);
        }

        return suma;
    }

    public static void main(String[] args) throws Exception{

        CharStream input = CharStreams.fromFileName("entrada.txt");

        MaclaurinLexer lexer = new MaclaurinLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        MaclaurinParser parser = new MaclaurinParser(tokens);

        parser.prog();

        double x = 1;
        int n = 10;

        double resultado = maclaurin(x,n);

        System.out.println("Aproximacion de e^x:");
        System.out.println(resultado);
    }
}
