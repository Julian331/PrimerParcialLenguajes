grammar Maclaurin;

prog : 'exp' '(' NUMBER ',' NUMBER ')' EOF ;

NUMBER : [0-9]+ ('.' [0-9]+)? ;

WS : [ \t\r\n]+ -> skip ;
