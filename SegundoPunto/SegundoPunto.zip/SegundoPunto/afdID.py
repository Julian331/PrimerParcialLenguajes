def es_letra(c):
    return ('a' <= c <= 'z') or ('A' <= c <= 'Z')

def es_numero(c):
    return '0' <= c <= '9'


def afd_id(cadena):

    estado = 0

    for c in cadena:

        if estado == 0:
            if es_letra(c):
                estado = 1
            else:
                return False

        elif estado == 1:
            if es_letra(c) or es_numero(c):
                estado = 1
            else:
                return False

    return estado == 1


archivo = open("pruebas.txt")

for linea in archivo:
    palabra = linea.strip()

    if afd_id(palabra):
        print(palabra, "ACEPTADO")
    else:
        print(palabra, "NO ACEPTADO")
