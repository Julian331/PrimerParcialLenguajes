#include <stdio.h>
#include <math.h>

extern double resultado;
extern double x;

int yyparse();
extern FILE *yyin;

double evaluar(char *archivo, double valor){
    FILE *f = fopen(archivo,"r");
    yyin = f;
    x = valor;
    yyparse();
    fclose(f);
    return resultado;
}

int main(){

    double x0 = 1.0;
    int i;

    for(i=0;i<10;i++){

        double fx = evaluar("funcion.txt",x0);
        double dfx = evaluar("derivada.txt",x0);

        double x1 = x0 - fx/dfx;

        printf("Iteracion %d -> x = %f\n",i,x1);

        x0 = x1;
    }

    return 0;
}
