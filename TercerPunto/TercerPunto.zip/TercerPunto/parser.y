%left PLUS MINUS
%left MUL DIV
%right POW
%{
#include <stdio.h>
#include <math.h>

double x;   /* valor actual de x */

int yylex();
void yyerror(const char *s);

double resultado;
%}

%union {
    double num;
}

%token <num> NUMBER
%token VAR
%token PLUS MINUS MUL DIV POW
%token LPAREN RPAREN

%type <num> expr

%%

input:
    expr { resultado = $1; }
;

expr:
      expr PLUS expr  { $$ = $1 + $3; }
    | expr MINUS expr { $$ = $1 - $3; }
    | expr MUL expr   { $$ = $1 * $3; }
    | expr DIV expr   { $$ = $1 / $3; }
    | expr POW expr   { $$ = pow($1,$3); }
    | LPAREN expr RPAREN { $$ = $2; }
    | NUMBER { $$ = $1; }
    | VAR { $$ = x; }
;

%%

void yyerror(const char *s){
    printf("Error: %s\n", s);
}
