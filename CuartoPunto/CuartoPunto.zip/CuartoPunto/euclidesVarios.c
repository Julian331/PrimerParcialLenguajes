#include <stdio.h>
#include <time.h>

int mcd(int a, int b){
    if(b == 0)
        return a;
    return mcd(b, a % b);
}

int main(){

    int pruebas[][2] = {
        {24,18},
        {25,10},
        {17,29},
        {123456,789012}
    };

    int n = 4;
    int resultado;

    clock_t inicio = clock();

    for(int i = 0; i < 1000000; i++){
        resultado = mcd(123456789,987654321);
    }

    clock_t fin = clock();

    double tiempo = (double)(fin - inicio) / CLOCKS_PER_SEC;

    printf("PRUEBAS DEL ALGORITMO DE EUCLIDES\n\n");

    for(int i = 0; i < n; i++){
        int a = pruebas[i][0];
        int b = pruebas[i][1];

        printf("MCD(%d,%d) = %d\n",a,b,mcd(a,b));
    }

    printf("\nTiempo C: %f segundos\n", tiempo);

    return 0;
}
