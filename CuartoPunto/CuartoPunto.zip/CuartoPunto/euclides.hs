import Data.Time.Clock

mcdEuclides :: Integer -> Integer -> Integer
mcdEuclides a 0 = a
mcdEuclides a b = mcdEuclides b (mod a b)

repetir :: Int -> Integer -> Integer -> Integer
repetir 0 a b = mcdEuclides a b
repetir n a b = repetir (n-1) a b

main = do
    let a = 123456789
    let b = 987654321
    let iteraciones = 1000000

    inicio <- getCurrentTime

    let resultado = repetir iteraciones a b

    fin <- getCurrentTime

    print resultado
    print (diffUTCTime fin inicio)
